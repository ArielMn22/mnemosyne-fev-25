import Header from "../../components/header";

const NewMemory = () => {

    return (
        <>
        
            <Header/>

            
        
        </>
    );

};

export default NewMemory;